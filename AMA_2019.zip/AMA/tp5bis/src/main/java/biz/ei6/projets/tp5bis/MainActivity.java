package biz.ei6.projets.tp5bis;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnValider = findViewById(R.id.main_activity_valider);
        btnValider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valider();
            }
        });

        Button btnAnnuler = findViewById(R.id.main_activity_annuler);
        btnAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remiseAZero();
            }
        });

        ImageView img = findViewById(R.id.main_activity_prend_photo);
        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                prendPhoto();
            }
        });


        Toolbar menu =findViewById(R.id.list_activity_menu);
        setSupportActionBar(menu);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }



    private void valider() {

        String nom =((TextView)findViewById(R.id.main_activity_nom)).getText().toString();
        String date =((TextView)findViewById(R.id.main_activity_date)).getText().toString();
        String telephone =((TextView)findViewById(R.id.main_activity_telephone)).getText().toString();

        String message = getString(R.string.chaine_message, nom, date, telephone);

        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();

        Intent intent = new Intent();
        intent.putExtra("anniv",new Anniversaire(nom,date,telephone));
        setResult(RESULT_OK,intent);
        finish();
    }

    private void remiseAZero() {
        ((TextView)findViewById(R.id.main_activity_nom)).setText("");
        ((TextView)findViewById(R.id.main_activity_date)).setText("");
        ((TextView)findViewById(R.id.main_activity_telephone)).setText("");

        Bitmap bm = BitmapFactory.decodeResource(getResources(), R.drawable.silhouette);
        ((ImageView)findViewById(R.id.main_activity_photo)).setImageBitmap(bm);
    }

    private final int CODE_IMAGE = 42;
    private void prendPhoto() {

        Intent intent  = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if(intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent,CODE_IMAGE);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == CODE_IMAGE) {
            if(resultCode == RESULT_OK) {
                Bundle extras = data.getExtras();
                Bitmap bm = (Bitmap) extras.get("data");
                ((ImageView)findViewById(R.id.main_activity_photo)).setImageBitmap(bm);
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
