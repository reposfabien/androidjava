package biz.ei6.ama.tp4;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class ListAnniversairesActivity extends AppCompatActivity {

    ArrayList<Anniversaire> data;
    boolean[] anniversairesSelectionnes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_anniversaires);

        anniversairesSelectionnes = new boolean[200];

        data = chargeLesDonnees();

        RecyclerView liste = findViewById(R.id.list_activity_anniversaires);

        AnniversairesAdapter adapter = new AnniversairesAdapter(this, data, anniversairesSelectionnes);
        liste.setAdapter(adapter);

        RecyclerView.LayoutManager mgr = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        liste.setLayoutManager(mgr);

    }

    private ArrayList<Anniversaire> chargeLesDonnees() {
        ArrayList<Anniversaire>  retVal = new ArrayList<>();

        for(int i=0; i<10; i++) {
            retVal.add(new Anniversaire("Fabien","06/06","0674641636"));
        }

        return  retVal;
    }
}
