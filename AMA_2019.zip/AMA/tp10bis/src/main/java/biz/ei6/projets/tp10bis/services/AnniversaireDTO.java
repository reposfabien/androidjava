package biz.ei6.projets.tp10bis.services;

public class AnniversaireDTO {


        private String  nom ;
        private String date ;
        private String telephone;

        public AnniversaireDTO(String nom, String date, String telephone) {
            this.nom = nom;
            this.date = date;
            this.telephone = telephone;
        }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
}
