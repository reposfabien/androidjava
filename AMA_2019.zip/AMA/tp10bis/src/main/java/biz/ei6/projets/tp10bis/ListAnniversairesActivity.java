package biz.ei6.projets.tp10bis;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import biz.ei6.projets.tp10bis.services.DataServiceAnniversaire.DataResponseListener;
import biz.ei6.projets.tp10bis.services.DataServiceAnniversaire;

public class ListAnniversairesActivity extends AppCompatActivity  implements DataResponseListener {

    private static final int CODE_CREATION_ANNIV = 1;
    ArrayList<Anniversaire> data;
    AnniversairesAdapter adapter;
    boolean[] anniversairesSelectionnes;

    //DataProvider dp;
    DataServiceAnniversaire dp = new DataServiceAnniversaire(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_anniversaires);

        //dp = new DataProvider(this,"http://10.0.2.2:3000/anniversaires","http://10.0.2.2:3000/anniversaires");
        //dp = new DataProvider(this,"http://192.168.1.16:3000/anniversaires","http://192.168.1.16:3000/anniversaires");

        anniversairesSelectionnes = new boolean[200];

        data = chargeLesDonnees();

        RecyclerView liste = findViewById(R.id.list_activity_anniversaires);

        adapter = new AnniversairesAdapter(this, data, anniversairesSelectionnes);
        liste.setAdapter(adapter);

        RecyclerView.LayoutManager mgr = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        liste.setLayoutManager(mgr);

        Toolbar menu =findViewById(R.id.list_activity_menu);
        setSupportActionBar(menu);
    }

    private ArrayList<Anniversaire> chargeLesDonnees() {
        ArrayList<Anniversaire>  retVal = new ArrayList<>();

        try {
           // dp.beginGetData();
            dp.call();

        } catch (Exception e) {
            Toast.makeText(this, "Impossible de charger les anniversaires", Toast.LENGTH_LONG).show();
        }


        return  retVal;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.principal,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.menu_nouveau) {
           Intent intent = new Intent(this, MainActivity.class);
           startActivityForResult(intent, CODE_CREATION_ANNIV);
        }
        else if(item.getItemId() == R.id.menu_souhaiter) {
            tenterSMS();
        }
        return super.onOptionsItemSelected(item);
    }

    private void afficherLesAnniversairesSelectionnes() {

        StringBuilder str = new StringBuilder();
        for (int position = 0; position < data.size(); position++) {
            if (anniversairesSelectionnes[position]) {
                str.append(data.get(position).getNom() + "\n");
            }

            TextView texte = findViewById(R.id.list_activity_selectionnes);
            texte.setText(str.toString());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent payload) {
        if(requestCode == CODE_CREATION_ANNIV) {
            if(resultCode == RESULT_OK) {
                Anniversaire anniv = payload.getParcelableExtra("anniv");
                data.add(anniv);
                adapter.notifyDataSetChanged();

                try {

                    AnniversaireCrud annivs = new AnniversaireCrud(this);

                    annivs.insertAnniversaires(anniv);

                    //dp.beginAjouterData(anniv);
                    dp.call();

                } catch (Exception e) {
                    Toast.makeText(this, "Impossible d'écrire les anniversaires", Toast.LENGTH_LONG).show();
                }
            }
        }
        super.onActivityResult(requestCode, resultCode, payload);
    }

    public void updateResultsTextfromSms(final List<String> messageenvoi) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (messageenvoi.size() == 0) {
                    Toast.makeText(ListAnniversairesActivity.this, getString(R.string.pas_de_messages), Toast.LENGTH_LONG).show();
                } else {

                    StringBuilder buff = new StringBuilder();
                    for (String s : messageenvoi) {
                        buff.append(s + "\n");
                    }
                    TextView texte = findViewById(R.id.list_activity_selectionnes);
                    texte.setText(buff.toString());
                }
            }
        });

    }

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;

    public void tenterSMS() {

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                //inutile ici

            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
        else {
            envoyerSMS();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {

        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0  && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    envoyerSMS();

                } else {
                    Toast.makeText(this,"Echec de l'envoi du SMS, non autorisé", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }

    }

    public void envoyerSMS() {

        MaTacheAsync api = new MaTacheAsync(data,anniversairesSelectionnes,this);
        api.execute();
    }

    @Override
    public void response(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
    }

    @Override
    public void response(Anniversaire map) {


        data.add(map);

        adapter.notifyDataSetChanged();
    }
}
