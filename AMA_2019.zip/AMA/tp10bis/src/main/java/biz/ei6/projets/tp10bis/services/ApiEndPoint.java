package biz.ei6.projets.tp10bis.services;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiEndPoint {

    @GET("anniversaires")
    Call<List<AnniversaireDTO>> getAnniversaires() ;
}

