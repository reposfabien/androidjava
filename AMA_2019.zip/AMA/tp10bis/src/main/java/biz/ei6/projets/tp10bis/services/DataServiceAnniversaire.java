package biz.ei6.projets.tp10bis.services;

import java.util.List;

import biz.ei6.projets.tp10bis.Anniversaire;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;



public class DataServiceAnniversaire {
    public interface DataResponseListener {

        void response(String error) ;

        void response(Anniversaire map);
    }

    private ApiEndPoint mApiService = null ;
    private DataResponseListener listener = null;

    public DataServiceAnniversaire(DataResponseListener listener) {
        this.listener = listener;

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.0.2.2:3000/")
                //.baseUrl("http://192.168.0.16:3000/")
                .addConverterFactory(GsonConverterFactory.create())
                .build() ;

        mApiService = retrofit.create(ApiEndPoint.class) ;
    }


    public void call() {

        Call call = mApiService.getAnniversaires() ;

        call.enqueue(new Callback<List<AnniversaireDTO>>() {
            @Override
            public void onResponse(Call<List<AnniversaireDTO>> call, Response<List<AnniversaireDTO>> response) {
                List<AnniversaireDTO> data = response.body();

                for (AnniversaireDTO res : data) {

                    Anniversaire d = new Anniversaire(res.getNom(), res.getDate(), res.getTelephone());
                    listener.response(d);
                }
            }

            @Override
            public void onFailure(Call<List<AnniversaireDTO>> call, Throwable t) {
                listener.response("Erreur "+t +" du call "+call.request().url());
            }

        });
    }

    public void removeListener() {
        listener = null;
    }
}
