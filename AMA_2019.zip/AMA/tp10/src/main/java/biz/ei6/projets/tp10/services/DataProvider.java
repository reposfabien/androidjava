package biz.ei6.projets.tp10.services;

import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import biz.ei6.projets.tp10.Anniversaire;

/**
 * Created by fabien on 18/09/2017.
 */

public class DataProvider {

    private static String TAG = "WSDATA";

    private Context mContext;
    private RequestQueue mRequestQueue;
    private String mUrlPost;
    private String mUrlGet;

    RequestQueue getRequestQueue () {
        if(mRequestQueue == null)
            mRequestQueue = Volley.newRequestQueue(mContext);
        return mRequestQueue;
    }

    public DataProvider(Context cxt, String urlPost, String urlGet) {
        mContext = cxt;
        mUrlGet = urlGet;
        mUrlPost = urlPost;
    }

    public void beginGetData() {

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET,mUrlGet,null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray tab) {
                        HashMap<String, String> map = new HashMap<>();
                        try {
                            for (int i=0; i<tab.length(); i++) {
                                JSONObject response = tab.getJSONObject(i);
                                Anniversaire anniv = new Anniversaire( response.get("nom").toString(),
                                                                        response.get("date").toString(),
                                                                        response.get("telephone").toString());
                                ((DataResponseListener) mContext).response(anniv);
                            }
                            } catch(JSONException e) {
                            e.printStackTrace();
                            ((DataResponseListener) mContext).response(e.toString());
                        }
                        
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        ((DataResponseListener)mContext).response(error.toString());
                    }
                });

        getRequestQueue().add(request);
    }
    public void beginAjouterData(Anniversaire anniv) {

        HashMap<String, String> map = new HashMap<>();

        map.put("nom",anniv.getNom());
        map.put("date",anniv.getDate());
        map.put("telephone",anniv.getTelephone());

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST,mUrlPost,new JSONObject(map),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        ((DataResponseListener)mContext).response("ok");
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        ((DataResponseListener)mContext).response(error.toString());
                    }
                });

        getRequestQueue().add(request);
    }

    public interface DataResponseListener {

        void response(String error);

        void response(Anniversaire map);
    }
}
