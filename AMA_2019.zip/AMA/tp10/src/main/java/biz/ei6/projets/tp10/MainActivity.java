package biz.ei6.projets.tp10;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnValider = findViewById(R.id.main_activity_valider);
        btnValider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                valider();
            }
        });

        Button btnAnnuler = findViewById(R.id.main_activity_annuler);
        btnAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                remiseAZero();
            }
        });

        Toolbar menu =findViewById(R.id.list_activity_menu);
        setSupportActionBar(menu);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    private void valider() {

        String nom =((TextView)findViewById(R.id.main_activity_nom)).getText().toString();
        String date =((TextView)findViewById(R.id.main_activity_date)).getText().toString();
        String telephone =((TextView)findViewById(R.id.main_activity_telephone)).getText().toString();

        String message = getString(R.string.chaine_message, nom, date, telephone);

        Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();

        Intent intent = new Intent();
        intent.putExtra("anniv",new Anniversaire(nom,date,telephone));
        setResult(RESULT_OK,intent);
        finish();
    }

    private void remiseAZero() {

    }


}
