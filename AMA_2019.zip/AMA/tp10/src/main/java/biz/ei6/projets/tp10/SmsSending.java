package biz.ei6.projets.tp10;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.telephony.SmsManager;
import android.widget.Toast;

/**
 * Created by fabien on 05/09/17.
 */

public class SmsSending {

    private Context mContext;
    private BroadcastReceiver mReceiver;

    public static int CODE_SMS = 1;

    public SmsSending(Context cxt) {
        mContext = cxt;

    }

    public void sendSMS(String telNum, String message) {
        String DELIVERED="SMS_DELIVERED";


        Intent intent = new Intent();
        PendingIntent deliveredPI = PendingIntent.getBroadcast(mContext,CODE_SMS,intent,0);

        mContext.registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {

                switch(getResultCode()) {
                    case Activity.RESULT_OK :
                        Toast.makeText(context,context.getString(R.string.message_envoye),Toast.LENGTH_LONG).show();
                        break;
                }
            }
        }, new IntentFilter(DELIVERED));

        SmsManager sms = SmsManager.getDefault();
        sms.sendTextMessage(telNum,null,message,null,deliveredPI);
    }
}
