package biz.ei6.projets.tp10;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by fabien on 04/09/17.
 */

public class AnnivsStructureDB  extends SQLiteOpenHelper {

    public static final String TABLE_ANNIVS = "table_anniversaires";
    public static final String COL_ID = "_id";
    public static final int NUM_COL_ID = 0;

    public static final String COL_NOM = "nom";
    public static final int NUM_COL_NOM = 1;

    public static final String COL_TELEPHONE = "telephone";
    public static final int NUM_COL_TELEPHONE = 3;

    public static final String COL_DATE = "date";
    public static final int NUM_COL_DATE = 2;

    private static final String CREATE_BDD = "CREATE TABLE "+TABLE_ANNIVS+
            "("+COL_ID+" INTEGER PRIMARY KEY AUTOINCREMENT, "+
            COL_NOM+" TEXT NOT NULL, "+
            COL_DATE+" TEXT NOT NULL, "+
            COL_TELEPHONE+" TEXT NOT NULL);";

    private SQLiteDatabase db;

    public AnnivsStructureDB(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        db = sqLiteDatabase;
        db.execSQL(CREATE_BDD);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        db.execSQL("DROP TABLE "+TABLE_ANNIVS);
        onCreate(db);
    }
}
