package biz.ei6.projets.tp9;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

/**
 * Created by fabien on 04/09/17.
 */

public class AnniversaireCrud {

    public static String NOM_BDD = "anniversaires";

    private AnnivsStructureDB mAnniversaires;
    private SQLiteDatabase bdd;

    public AnniversaireCrud(Context cxt) { mAnniversaires = new AnnivsStructureDB(cxt,NOM_BDD,null,1);}

    public void openForWrite() { bdd = mAnniversaires.getWritableDatabase();}
    public void openForRead() { bdd = mAnniversaires.getReadableDatabase();}

    public void close() { mAnniversaires.close();}

    public long insertAnniversaires(Anniversaire anniv) {

        openForWrite();

        ContentValues cv = new ContentValues();
        cv.put(AnnivsStructureDB.COL_NOM, anniv.getNom());
        cv.put(AnnivsStructureDB.COL_DATE, anniv.getDate());
        cv.put(AnnivsStructureDB.COL_TELEPHONE, anniv.getTelephone());

        long retval= bdd.insert(AnnivsStructureDB.TABLE_ANNIVS,null,cv);

        close();

        return retval;
    }

    public ArrayList<Anniversaire> getAllAnniversaires() {
        ArrayList<Anniversaire> retval = new ArrayList<>();

        openForRead();

        Cursor c = bdd.query(AnnivsStructureDB.TABLE_ANNIVS,
                new String[]{AnnivsStructureDB.COL_ID,AnnivsStructureDB.COL_NOM,AnnivsStructureDB.COL_DATE,AnnivsStructureDB.COL_TELEPHONE},
                null, null, null,null,AnnivsStructureDB.COL_NOM);

        if(c.getCount()>0){
            while(c.moveToNext()) {
                retval.add(new Anniversaire(c.getString(AnnivsStructureDB.NUM_COL_NOM),
                        c.getString(AnnivsStructureDB.NUM_COL_DATE),
                        c.getString(AnnivsStructureDB.NUM_COL_TELEPHONE)));
            }
        }

        close();

        return retval;
    }
}
