package biz.ei6.projets.tp9;

import android.app.Activity;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by fabien on 05/09/17.
 */

public class MaTacheAsync extends AsyncTask<Void,Void,Void> {

    ArrayList<Anniversaire> listeAnnivs;
    boolean[] checkBoxState;
    ListAnniversairesActivity activity;

    public MaTacheAsync(ArrayList<Anniversaire> liste, boolean[]  check, Activity activity){
        this.listeAnnivs = liste;
        this.checkBoxState = check;
        this.activity = (ListAnniversairesActivity)activity;
    }

    @Override
    protected Void doInBackground(Void... voids) {
        activity.updateResultsTextfromSms(sendSms());
        return null;
    }

    private List<String> sendSms() {
        List<String> retval = new ArrayList<>();

        SmsSending ss = new SmsSending(activity);

        for( int i = 0; i<listeAnnivs.size();i++) {
            if(checkBoxState[i]) {
                String tel = listeAnnivs.get(i).getTelephone();
                retval.add(tel);
                ss.sendSMS(tel,"Bon anniversaire "+listeAnnivs.get(i).getNom());
            }
        }

        return retval;
    }
}