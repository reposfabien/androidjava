package biz.ei6.ama.tp1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MAIN_ACTIVITY";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG," appli onStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG," appli onResume");
    }

    @Override
    protected void onPause() {
        Log.d(TAG," appli onPause");
        super.onPause();
    }

    @Override
    protected void onStop() {
        Log.d(TAG," appli onStop");
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        Log.d(TAG," appli onDestroy");
        super.onDestroy();
    }
}
