package biz.ei6.projets.tp8bis.dao;


import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Anniversaire.class}, version = 1, exportSchema = true)
    public abstract class AnnivDatabase extends RoomDatabase {
        public abstract AnniversaireDAO anniversaireDao();
    }


