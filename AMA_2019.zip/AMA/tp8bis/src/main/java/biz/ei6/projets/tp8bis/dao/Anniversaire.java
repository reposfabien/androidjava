package biz.ei6.projets.tp8bis.dao;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

@Entity
public class Anniversaire implements Parcelable {

    @PrimaryKey
    public int id;

    private String nom;
    private String date;
    private String telephone;
    private String photo;

    @Ignore
    public Anniversaire(String nom, String date, String telephone) {
        this.nom = nom;
        this.date = date;
        this.telephone = telephone;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.nom);
        dest.writeString(this.date);
        dest.writeString(this.telephone);
        dest.writeString(this.photo);
    }

    public Anniversaire() {
    }

    protected Anniversaire(Parcel in) {
        this.nom = in.readString();
        this.date = in.readString();
        this.telephone = in.readString();
        this.photo = in.readString();
    }

    public static final Creator<Anniversaire> CREATOR = new Creator<Anniversaire>() {
        @Override
        public Anniversaire createFromParcel(Parcel source) {
            return new Anniversaire(source);
        }

        @Override
        public Anniversaire[] newArray(int size) {
            return new Anniversaire[size];
        }
    };
}
