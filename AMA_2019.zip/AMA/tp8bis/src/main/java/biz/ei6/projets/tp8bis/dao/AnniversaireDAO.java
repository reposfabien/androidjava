package biz.ei6.projets.tp8bis.dao;


import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface AnniversaireDAO {

    @Insert
    void insertAnniversaires(Anniversaire anniv);

    @Query("SELECT * from anniversaire")
    Anniversaire[] getAllAnniversaires();
}
