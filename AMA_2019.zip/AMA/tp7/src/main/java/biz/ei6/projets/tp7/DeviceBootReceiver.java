package biz.ei6.projets.tp7;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

/**
 * Created by fabien on 04/09/17.
 */

public class DeviceBootReceiver  extends BroadcastReceiver {

    private static final int CODE_ALARM = 1;

    @Override
    public void onReceive(Context context, Intent intent) {

        Toast.makeText(context, "L'alarme va être enclenchée",Toast.LENGTH_LONG).show();

        Intent chrono = new Intent(context,AlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context,CODE_ALARM,chrono,0);

        AlarmManager am = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        am.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis(),1000*10,pi);


    }
}
