package biz.ei6.projets.tp7;

import android.content.Context;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by fabien on 04/09/17.
 */

public class HistoryFile {

    private Context mContext;
    private File mAnnivFile;

    public HistoryFile(Context context) {
        mContext = context;
    }

    public boolean isFileExist() {

        mAnnivFile = new File(mContext.getExternalFilesDir(null),"anniversaies.txt");


        return mAnnivFile.exists();
    }

    List<String> getAnniversaires() throws Exception {
        List<String> retval = new ArrayList<>();
        try (FileReader fr = new FileReader(mAnnivFile);
             BufferedReader br = new BufferedReader(fr)) {
            String ligne;
            while((ligne = br.readLine()) !=null) {
                retval.add(ligne);
            }
        }

        return retval;
    }

    public void saveAnniversaires(String anniv) throws IOException {

        if(!isFileExist())
            mAnnivFile.createNewFile();

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(mAnnivFile,true)))  {
            bw.write(anniv);
            bw.newLine();
        }

    }
}
