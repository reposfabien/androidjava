package biz.ei6.projets.tp7;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;


public class AnniversairesAdapter  extends RecyclerView.Adapter<AnniversairesAdapter.VH>{

    private LayoutInflater inflater;
    private final ArrayList<Anniversaire> data;
    private boolean[] checkBoxState;

    public AnniversairesAdapter(Activity cxt, ArrayList<Anniversaire> data, boolean[] checkBoxState) {
        this.data = data;
        this.inflater = cxt.getLayoutInflater();
        this.checkBoxState = checkBoxState;
    }
    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = inflater.inflate(R.layout.list_item,null);

        return new VH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VH vh, final int i) {
        vh.nomTxt.setText( data.get(i).getNom());
        vh.dateTxt.setText( data.get(i).getDate());
        vh.telephoneTxt.setText( data.get(i).getTelephone());
        vh.checkBox.setChecked(checkBoxState[i]);

        vh.checkBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBoxState[i] = ((CheckBox)view).isChecked();
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class VH extends RecyclerView.ViewHolder {

        TextView nomTxt;
        TextView dateTxt;
        TextView telephoneTxt;
        ImageView photoImg;
        CheckBox checkBox;

        public VH(@NonNull View itemView) {
            super(itemView);

            nomTxt = itemView.findViewById(R.id.list_activity_item_nom);
            dateTxt = itemView.findViewById(R.id.list_activity_item_date);
            telephoneTxt = itemView.findViewById(R.id.list_activity_item_telephone);
            photoImg = itemView.findViewById(R.id.list_activity_item_photo);
            checkBox = itemView.findViewById(R.id.list_activity_item_check);
        }
    }
}
