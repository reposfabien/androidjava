package biz.ei6.projets.tp5;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.util.ArrayList;

public class ListAnniversairesActivity extends AppCompatActivity {

    private static final int CODE_CREATION_ANNIV = 1;
    ArrayList<Anniversaire> data;
    AnniversairesAdapter adapter;
    boolean[] anniversairesSelectionnes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_anniversaires);

        anniversairesSelectionnes = new boolean[200];

        data = chargeLesDonnees();

        RecyclerView liste = findViewById(R.id.list_activity_anniversaires);

        adapter = new AnniversairesAdapter(this, data, anniversairesSelectionnes);
        liste.setAdapter(adapter);

        RecyclerView.LayoutManager mgr = new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false);
        liste.setLayoutManager(mgr);

        Toolbar menu =findViewById(R.id.list_activity_menu);
        setSupportActionBar(menu);


    }

    private ArrayList<Anniversaire> chargeLesDonnees() {
        ArrayList<Anniversaire>  retVal = new ArrayList<>();

        for(int i=0; i<10; i++) {
            retVal.add(new Anniversaire("Fabien","06/06","0674641636"));
        }

        return  retVal;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.principal,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == R.id.menu_nouveau) {
           Intent intent = new Intent(this, MainActivity.class);
           startActivityForResult(intent, CODE_CREATION_ANNIV);
        }
        else if(item.getItemId() == R.id.menu_souhaiter) {
          afficherLesAnniversairesSelectionnes();
        }
        return super.onOptionsItemSelected(item);
    }

    private void afficherLesAnniversairesSelectionnes() {

        StringBuilder str = new StringBuilder();
        for (int position = 0; position < data.size(); position++) {
            if (anniversairesSelectionnes[position]) {
                str.append(data.get(position).getNom() + "\n");
            }

            TextView texte = findViewById(R.id.list_activity_selectionnes);
            texte.setText(str.toString());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent payload) {
        if(requestCode == CODE_CREATION_ANNIV) {
            if(resultCode == RESULT_OK) {
                Anniversaire anniv = payload.getParcelableExtra("anniv");
                data.add(anniv);
                adapter.notifyDataSetChanged();
            }
        }
        super.onActivityResult(requestCode, resultCode, payload);
    }
}
